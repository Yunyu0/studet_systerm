package com.chenwanyu.po;

/**
 * College扩展类
 */
public class CollegeCustom extends College {



}
