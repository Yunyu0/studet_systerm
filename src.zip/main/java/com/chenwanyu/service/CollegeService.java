package com.chenwanyu.service;

import com.chenwanyu.po.College;

import java.util.List;


public interface CollegeService {

    List<College> finAll() throws Exception;

}
